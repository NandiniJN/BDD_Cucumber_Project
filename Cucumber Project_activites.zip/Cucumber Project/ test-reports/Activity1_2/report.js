$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity1_2.feature");
formatter.feature({
  "line": 2,
  "name": "Login Test",
  "description": "",
  "id": "login-test",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity1_2"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Testing Login",
  "description": "",
  "id": "login-test;testing-login",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User enters username and password",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Read the page title and confirmation message",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "LoginTestSteps.loginPage()"
});
formatter.result({
  "duration": 17439392599,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestSteps.enterCredentials()"
});
formatter.result({
  "duration": 913002300,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestSteps.readTitleAndHeading()"
});
formatter.result({
  "duration": 352293599,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestSteps.closeBrowser()"
});
formatter.result({
  "duration": 10481252000,
  "status": "passed"
});
});