$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity1_3.feature");
formatter.feature({
  "line": 2,
  "name": "Testing with Tags",
  "description": "",
  "id": "testing-with-tags",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity1_3"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Test for Simple Alert",
  "description": "",
  "id": "testing-with-tags;test-for-simple-alert",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@SimpleAlert"
    },
    {
      "line": 4,
      "name": "@SmokeTest"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is on the page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User clicks the Simple Alert button",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "Alert opens",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Read the text from it and print it",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Close the alert",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Close Browser",
  "keyword": "And "
});
formatter.match({
  "location": "AlertTestSteps.openPage()"
});
formatter.result({
  "duration": 15002920701,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.openSimpleAlert()"
});
formatter.result({
  "duration": 264714300,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.switchFocus()"
});
formatter.result({
  "duration": 57569100,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.readAlert()"
});
formatter.result({
  "duration": 23533901,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.closeAlert()"
});
formatter.result({
  "duration": 83274600,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.closeBrowser()"
});
formatter.result({
  "duration": 3137703099,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Test for Confirm Alert",
  "description": "",
  "id": "testing-with-tags;test-for-confirm-alert",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 13,
      "name": "@ConfirmAlert"
    }
  ]
});
formatter.step({
  "line": 15,
  "name": "User is on the page",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "User clicks the Confirm Alert button",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "Alert opens",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "Read the text from it and print it",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "Close the alert with Cancel",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "Close Browser",
  "keyword": "And "
});
formatter.match({
  "location": "AlertTestSteps.openPage()"
});
formatter.result({
  "duration": 11668124500,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.openConfirmAlert()"
});
formatter.result({
  "duration": 110787400,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.switchFocus()"
});
formatter.result({
  "duration": 43379600,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.readAlert()"
});
formatter.result({
  "duration": 13988500,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.closeAlertWithCAncel()"
});
formatter.result({
  "duration": 42741701,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.closeBrowser()"
});
formatter.result({
  "duration": 4700561899,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Test for Prompt Alert",
  "description": "",
  "id": "testing-with-tags;test-for-prompt-alert",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 22,
      "name": "@PromptAlert"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "User is on the page",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "User clicks the Prompt Alert button",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "Alert opens",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "Read the text from it and print it",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "Write a custom message in it",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "Close the alert",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "Close Browser",
  "keyword": "And "
});
formatter.match({
  "location": "AlertTestSteps.openPage()"
});
formatter.result({
  "duration": 12209546800,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.openPromptAlert()"
});
formatter.result({
  "duration": 140454899,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.switchFocus()"
});
formatter.result({
  "duration": 59123401,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.readAlert()"
});
formatter.result({
  "duration": 6245800,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.writeToPrompt()"
});
formatter.result({
  "duration": 22738701,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.closeAlert()"
});
formatter.result({
  "duration": 92314801,
  "status": "passed"
});
formatter.match({
  "location": "AlertTestSteps.closeBrowser()"
});
formatter.result({
  "duration": 5171160499,
  "status": "passed"
});
});