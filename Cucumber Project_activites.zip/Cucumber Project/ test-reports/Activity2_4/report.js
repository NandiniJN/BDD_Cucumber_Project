$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity2_4.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test without Example",
  "description": "",
  "id": "data-driven-test-without-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_4"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-without-example;testing-with-data-from-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User is on the Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User enters the \"admin\" and \"password\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Read the page title and the confirmation message",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the Browser at the end",
  "keyword": "And "
});
formatter.match({
  "location": "Activity2_LoginTestSteps.loginPage()"
});
formatter.result({
  "duration": 13976523500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 17
    },
    {
      "val": "password",
      "offset": 29
    }
  ],
  "location": "Activity2_LoginTestSteps.user_enters_and(String,String)"
});
formatter.result({
  "duration": 800310800,
  "status": "passed"
});
formatter.match({
  "location": "Activity2_LoginTestSteps.readTitleAndHeading()"
});
formatter.result({
  "duration": 178322499,
  "status": "passed"
});
formatter.match({
  "location": "Activity2_LoginTestSteps.closeBrowser()"
});
formatter.result({
  "duration": 3413313100,
  "status": "passed"
});
});