$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity2_5.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_5"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User is on the Login page on browser",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User enters the \"\u003cUsernames\u003e\" and the \"\u003cPasswords\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Read the page title and the confirmation message on the page",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the Browser at end of the page",
  "keyword": "And "
});
formatter.examples({
  "line": 10,
  "name": "",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;",
  "rows": [
    {
      "cells": [
        "Usernames",
        "Passwords"
      ],
      "line": 11,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;1"
    },
    {
      "cells": [
        "admin",
        "password"
      ],
      "line": 12,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2"
    },
    {
      "cells": [
        "adminUser",
        "Password"
      ],
      "line": 13,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 12,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_5"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User is on the Login page on browser",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User enters the \"admin\" and the \"password\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Read the page title and the confirmation message on the page",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the Browser at end of the page",
  "keyword": "And "
});
formatter.match({
  "location": "Activity2_5_LoginTestSteps.loginPage()"
});
formatter.result({
  "duration": 15059426300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 17
    },
    {
      "val": "password",
      "offset": 33
    }
  ],
  "location": "Activity2_5_LoginTestSteps.user_enters_and(String,String)"
});
formatter.result({
  "duration": 806678400,
  "status": "passed"
});
formatter.match({
  "location": "Activity2_5_LoginTestSteps.readTitleAndHeading()"
});
formatter.result({
  "duration": 244335100,
  "status": "passed"
});
formatter.match({
  "location": "Activity2_5_LoginTestSteps.closeBrowser()"
});
formatter.result({
  "duration": 4032791601,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_5"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User is on the Login page on browser",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User enters the \"adminUser\" and the \"Password\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Read the page title and the confirmation message on the page",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the Browser at end of the page",
  "keyword": "And "
});
formatter.match({
  "location": "Activity2_5_LoginTestSteps.loginPage()"
});
formatter.result({
  "duration": 10879727000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "adminUser",
      "offset": 17
    },
    {
      "val": "Password",
      "offset": 37
    }
  ],
  "location": "Activity2_5_LoginTestSteps.user_enters_and(String,String)"
});
formatter.result({
  "duration": 548113200,
  "status": "passed"
});
formatter.match({
  "location": "Activity2_5_LoginTestSteps.readTitleAndHeading()"
});
formatter.result({
  "duration": 112206200,
  "status": "passed"
});
formatter.match({
  "location": "Activity2_5_LoginTestSteps.closeBrowser()"
});
formatter.result({
  "duration": 3594045800,
  "status": "passed"
});
});