package cucumberTest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;

import cucumber.api.junit.Cucumber;

 

@RunWith(Cucumber.class)

@CucumberOptions(

    features = "src/Features",

    glue = {"stepDefinition"},

    tags = {"@activity1_3"},

    strict = true,
    plugin = {"pretty" , "html: test-reports/Activity1_3" , "json: test-reports/Activity1_3/json-report.json"},
    monochrome = true


)

public class ActivitiesRunnerAlert {

}
