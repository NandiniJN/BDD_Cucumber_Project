package cucumberTest;


import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(

    features = "src/Features",

    glue = {"stepDefinition"},

    tags = {"@activity2_5"},

    strict = true,
    plugin = {"pretty" , "html: test-reports/Activity2_5" , "json: test-reports/Activity2_5/json-report.json"},
    monochrome = true


)
public class Activity_2_5_ActivitiesRunner {

}
