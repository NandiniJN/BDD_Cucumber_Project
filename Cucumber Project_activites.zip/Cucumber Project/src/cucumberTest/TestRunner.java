package cucumberTest;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/Features",
    glue = {"stepDefinition"},
    tags = {"@Activity1_1"},
    strict = true,
    plugin = {"pretty" , "html: test-reports/Activity1_1" , "json: test-reports/Activity1_1/json-report.json"},
    monochrome = true

)

public class TestRunner {
    //empty
}