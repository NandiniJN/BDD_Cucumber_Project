$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CRM_CreateLeads.feature");
formatter.feature({
  "line": 2,
  "name": "Create leads using parameterization",
  "description": "I want to use this template for my feature file",
  "id": "create-leads-using-parameterization",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@CRMCreateLeads"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Open the Leads page and add multiple lead accounts using values passed from file",
  "description": "",
  "id": "create-leads-using-parameterization;open-the-leads-page-and-add-multiple-lead-accounts-using-values-passed-from-file",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "User has to login to Alchemy CRM page using credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Navigate to Sales then Leads and then Create Lead",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Fill the necessary details by giving FirstName \"Nandini\" and LastName \"JN\" and Description \"CreateLead\"",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "User clicks on Save button",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Navigate to View Leads page to see the results",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "Close Alchemy CRM page",
  "keyword": "And "
});
formatter.match({
  "location": "CRM_CreateLeads.userison_AlchemyCRM()"
});
formatter.result({
  "duration": 10262162900,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateLeads.Sales_leads_createlead()"
});
formatter.result({
  "duration": 6369933600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Nandini",
      "offset": 48
    },
    {
      "val": "JN",
      "offset": 71
    },
    {
      "val": "CreateLead",
      "offset": 92
    }
  ],
  "location": "CRM_CreateLeads.Filledetails(String,String,String)"
});
formatter.result({
  "duration": 3546875100,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateLeads.SavetoFinish()"
});
formatter.result({
  "duration": 3973363500,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateLeads.Navigatetoleadpage()"
});
formatter.result({
  "duration": 4353605600,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateLeads.closeoff_Alchemy_CRM()"
});
formatter.result({
  "duration": 1560901200,
  "status": "passed"
});
});