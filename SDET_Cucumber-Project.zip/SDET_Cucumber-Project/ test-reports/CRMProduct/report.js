$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CRM_CreateProduct.feature");
formatter.feature({
  "line": 2,
  "name": "Creating a Product",
  "description": "",
  "id": "creating-a-product",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@CRMCreateProduct"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "To use an external Excel to add products",
  "description": "",
  "id": "creating-a-product;to-use-an-external-excel-to-add-products",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "Open the Alchemy CRM site and login",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user navigates to All then Products and then Create Product",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "enter the details of the product \"\u003cProductName\u003e\" and \"\u003cPrice\u003e\" and \"\u003cDescription\u003e\" using data from table",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "click Save To Create Product",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "go to the View Products page to see all products listed",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "exit the CRM browser",
  "keyword": "And "
});
formatter.examples({
  "line": 12,
  "name": "",
  "description": "",
  "id": "creating-a-product;to-use-an-external-excel-to-add-products;",
  "rows": [
    {
      "cells": [
        "ProductName",
        "Price",
        "Description"
      ],
      "line": 13,
      "id": "creating-a-product;to-use-an-external-excel-to-add-products;;1"
    },
    {
      "cells": [
        "NNCRMProduct",
        "10",
        "Adding Product1"
      ],
      "line": 14,
      "id": "creating-a-product;to-use-an-external-excel-to-add-products;;2"
    },
    {
      "cells": [
        "CCCRMProduct",
        "20",
        "Adding Product2"
      ],
      "line": 15,
      "id": "creating-a-product;to-use-an-external-excel-to-add-products;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 14,
  "name": "To use an external Excel to add products",
  "description": "",
  "id": "creating-a-product;to-use-an-external-excel-to-add-products;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@CRMCreateProduct"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "Open the Alchemy CRM site and login",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user navigates to All then Products and then Create Product",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "enter the details of the product \"NNCRMProduct\" and \"10\" and \"Adding Product1\" using data from table",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "click Save To Create Product",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "go to the View Products page to see all products listed",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "exit the CRM browser",
  "keyword": "And "
});
formatter.match({
  "location": "CRM_CreateProduct.AlchemyCRMLogin()"
});
formatter.result({
  "duration": 11399861900,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateProduct.products()"
});
formatter.result({
  "duration": 11437037100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "NNCRMProduct",
      "offset": 34
    },
    {
      "val": "10",
      "offset": 53
    },
    {
      "val": "Adding Product1",
      "offset": 62
    }
  ],
  "location": "CRM_CreateProduct.ProductDetails(String,String,String)"
});
formatter.result({
  "duration": 197911500,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateProduct.SaveProduct()"
});
formatter.result({
  "duration": 6397856300,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateProduct.verifyproducts()"
});
formatter.result({
  "duration": 978069800,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateProduct.existCRMPage()"
});
formatter.result({
  "duration": 1964304200,
  "status": "passed"
});
formatter.scenario({
  "line": 15,
  "name": "To use an external Excel to add products",
  "description": "",
  "id": "creating-a-product;to-use-an-external-excel-to-add-products;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@CRMCreateProduct"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "Open the Alchemy CRM site and login",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user navigates to All then Products and then Create Product",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "enter the details of the product \"CCCRMProduct\" and \"20\" and \"Adding Product2\" using data from table",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "click Save To Create Product",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "go to the View Products page to see all products listed",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "exit the CRM browser",
  "keyword": "And "
});
formatter.match({
  "location": "CRM_CreateProduct.AlchemyCRMLogin()"
});
formatter.result({
  "duration": 10617779500,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateProduct.products()"
});
formatter.result({
  "duration": 8048875800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "CCCRMProduct",
      "offset": 34
    },
    {
      "val": "20",
      "offset": 53
    },
    {
      "val": "Adding Product2",
      "offset": 62
    }
  ],
  "location": "CRM_CreateProduct.ProductDetails(String,String,String)"
});
formatter.result({
  "duration": 326920100,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateProduct.SaveProduct()"
});
formatter.result({
  "duration": 6649924500,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateProduct.verifyproducts()"
});
formatter.result({
  "duration": 1178010700,
  "status": "passed"
});
formatter.match({
  "location": "CRM_CreateProduct.existCRMPage()"
});
formatter.result({
  "duration": 1185621900,
  "status": "passed"
});
});