$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CRM_countingdashlets.feature");
formatter.feature({
  "line": 2,
  "name": "To count the dashlets on the CRM page",
  "description": "",
  "id": "to-count-the-dashlets-on-the-crm-page",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@countingdashlets"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "count and print the dashlets on CRM page",
  "description": "",
  "id": "to-count-the-dashlets-on-the-crm-page;count-and-print-the-dashlets-on-crm-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User has to login to CRM page using credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Count the number of dashlets on CRM Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "print the number of dashlets into console",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the CRM Browser",
  "keyword": "And "
});
formatter.match({
  "location": "CRM_countingdashlets.logintoCRMpage()"
});
formatter.result({
  "duration": 18169772500,
  "status": "passed"
});
formatter.match({
  "location": "CRM_countingdashlets.count_the_number_of_Dashlets_on_Hompepage()"
});
formatter.result({
  "duration": 74029200,
  "status": "passed"
});
formatter.match({
  "location": "CRM_countingdashlets.print_the_number_of_dashlets_into_console()"
});
formatter.result({
  "duration": 1131971500,
  "status": "passed"
});
formatter.match({
  "location": "CRM_countingdashlets.closeCRMpage()"
});
formatter.result({
  "duration": 2730712200,
  "status": "passed"
});
});