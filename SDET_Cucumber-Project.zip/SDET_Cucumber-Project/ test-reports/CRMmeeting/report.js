$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CRM_MeetingInviteFriends.feature");
formatter.feature({
  "line": 2,
  "name": "Schedule a meeting and invite members",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@CRMMeetingfriends"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "To schedule a meeting and include at least 3 invitees",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 6,
  "name": "Login to CRM with credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Navigate to Activities then Meetings and then Schedule a Meeting",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Enter the \"\u003cSubject\u003e\" and Search for members \"\u003cName\u003e\" and add them to the meeting",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click Save Meeting to finish",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Navigate to View Meetings page and confirm creation of the meeting for \"\u003cSubject\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "close the CRM browser",
  "keyword": "Then "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;",
  "rows": [
    {
      "cells": [
        "Subject",
        "Name"
      ],
      "line": 14,
      "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;1"
    },
    {
      "cells": [
        "Team Meeting for Testers",
        "QAUsers"
      ],
      "line": 15,
      "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;2"
    },
    {
      "cells": [
        "Team Meeting for Development",
        "DEVUsers"
      ],
      "line": 16,
      "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;3"
    },
    {
      "cells": [
        "Team Meeting for BA",
        "BAUsers"
      ],
      "line": 17,
      "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 15,
  "name": "To schedule a meeting and include at least 3 invitees",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@CRMMeetingfriends"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "Login to CRM with credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Navigate to Activities then Meetings and then Schedule a Meeting",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Enter the \"Team Meeting for Testers\" and Search for members \"QAUsers\" and add them to the meeting",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click Save Meeting to finish",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Navigate to View Meetings page and confirm creation of the meeting for \"Team Meeting for Testers\"",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "close the CRM browser",
  "keyword": "Then "
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.logintoCRMpage()"
});
formatter.result({
  "duration": 10989992200,
  "status": "passed"
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.ScheduleMeeting()"
});
formatter.result({
  "duration": 6682312800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Team Meeting for Testers",
      "offset": 11
    },
    {
      "val": "QAUsers",
      "offset": 61
    }
  ],
  "location": "CRM_MeetingInviteFriends.bookmeeting(String,String)"
});
formatter.result({
  "duration": 6704643800,
  "status": "passed"
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.click_Save()"
});
formatter.result({
  "duration": 2204209100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Team Meeting for Testers",
      "offset": 72
    }
  ],
  "location": "CRM_MeetingInviteFriends.ConfirmMeeting(String)"
});
formatter.result({
  "duration": 2678894000,
  "status": "passed"
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.CloseCRMBrowser()"
});
formatter.result({
  "duration": 1139644700,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "To schedule a meeting and include at least 3 invitees",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@CRMMeetingfriends"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "Login to CRM with credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Navigate to Activities then Meetings and then Schedule a Meeting",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Enter the \"Team Meeting for Development\" and Search for members \"DEVUsers\" and add them to the meeting",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click Save Meeting to finish",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Navigate to View Meetings page and confirm creation of the meeting for \"Team Meeting for Development\"",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "close the CRM browser",
  "keyword": "Then "
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.logintoCRMpage()"
});
formatter.result({
  "duration": 9499364600,
  "status": "passed"
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.ScheduleMeeting()"
});
formatter.result({
  "duration": 6433952000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Team Meeting for Development",
      "offset": 11
    },
    {
      "val": "DEVUsers",
      "offset": 65
    }
  ],
  "location": "CRM_MeetingInviteFriends.bookmeeting(String,String)"
});
formatter.result({
  "duration": 6899711500,
  "status": "passed"
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.click_Save()"
});
formatter.result({
  "duration": 2217704600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Team Meeting for Development",
      "offset": 72
    }
  ],
  "location": "CRM_MeetingInviteFriends.ConfirmMeeting(String)"
});
formatter.result({
  "duration": 2677034600,
  "status": "passed"
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.CloseCRMBrowser()"
});
formatter.result({
  "duration": 1150127000,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "To schedule a meeting and include at least 3 invitees",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@CRMMeetingfriends"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "Login to CRM with credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Navigate to Activities then Meetings and then Schedule a Meeting",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Enter the \"Team Meeting for BA\" and Search for members \"BAUsers\" and add them to the meeting",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click Save Meeting to finish",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Navigate to View Meetings page and confirm creation of the meeting for \"Team Meeting for BA\"",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "close the CRM browser",
  "keyword": "Then "
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.logintoCRMpage()"
});
formatter.result({
  "duration": 9316353300,
  "status": "passed"
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.ScheduleMeeting()"
});
formatter.result({
  "duration": 6387363000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Team Meeting for BA",
      "offset": 11
    },
    {
      "val": "BAUsers",
      "offset": 56
    }
  ],
  "location": "CRM_MeetingInviteFriends.bookmeeting(String,String)"
});
formatter.result({
  "duration": 6737452200,
  "status": "passed"
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.click_Save()"
});
formatter.result({
  "duration": 2633048500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Team Meeting for BA",
      "offset": 72
    }
  ],
  "location": "CRM_MeetingInviteFriends.ConfirmMeeting(String)"
});
formatter.result({
  "duration": 2847108300,
  "status": "passed"
});
formatter.match({
  "location": "CRM_MeetingInviteFriends.CloseCRMBrowser()"
});
formatter.result({
  "duration": 1148586700,
  "status": "passed"
});
});