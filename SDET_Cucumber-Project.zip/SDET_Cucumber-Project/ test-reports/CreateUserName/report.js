$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CreateUserName.feature");
formatter.feature({
  "line": 2,
  "name": "create new user",
  "description": "",
  "id": "create-new-user",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@createusername"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Visit the site�s backend and create a new user",
  "description": "",
  "id": "create-new-user;visit-the-site�s-backend-and-create-a-new-user",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User is on admin page and login",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User enters the user name and password",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "User need to locate the menu item and click on Users button",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "click \"Add New\" button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "fill necessary details and click on \"Add New User\" button",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "verify the user details after adding",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Close the browser",
  "keyword": "And "
});
formatter.match({
  "location": "createNewUser.adminpage()"
});
formatter.result({
  "duration": 16136965300,
  "status": "passed"
});
formatter.match({
  "location": "createNewUser.entervalidcredentials()"
});
formatter.result({
  "duration": 3882667500,
  "status": "passed"
});
formatter.match({
  "location": "createNewUser.menuitem()"
});
formatter.result({
  "duration": 2617263900,
  "status": "passed"
});
formatter.match({
  "location": "createNewUser.addnewuser()"
});
formatter.result({
  "duration": 1587615100,
  "status": "passed"
});
formatter.match({
  "location": "createNewUser.filldetails()"
});
formatter.result({
  "duration": 2885848300,
  "status": "passed"
});
formatter.match({
  "location": "createNewUser.verifydetails()"
});
formatter.result({
  "duration": 2439864200,
  "status": "passed"
});
formatter.match({
  "location": "createNewUser.browserclose()"
});
formatter.result({
  "duration": 4611027300,
  "status": "passed"
});
});