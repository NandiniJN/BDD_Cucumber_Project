$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("HRM_jobvacancy.feature");
formatter.feature({
  "line": 2,
  "name": "job vacancy for dev ops engineer",
  "description": "",
  "id": "job-vacancy-for-dev-ops-engineer",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@hrmjobvacancy"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "To create a job vacancy for DevOps Engineer",
  "description": "",
  "id": "job-vacancy-for-dev-ops-engineer;to-create-a-job-vacancy-for-devops-engineer",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User has to login to HRM page using credentials and navigate to Recruitment page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "enter to vacancies page and click on Add button",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "In add vacancy form fill out all necessary details and save it",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "verify the vacancy was created on the page",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Close the HRM Browser",
  "keyword": "And "
});
formatter.match({
  "location": "HRM_jobvacancy.logintoHRMpage()"
});
formatter.result({
  "duration": 20687780300,
  "status": "passed"
});
formatter.match({
  "location": "HRM_jobvacancy.vacancypage()"
});
formatter.result({
  "duration": 2568938700,
  "status": "passed"
});
formatter.match({
  "location": "HRM_jobvacancy.vacancyform()"
});
formatter.result({
  "duration": 2124779500,
  "status": "passed"
});
formatter.match({
  "location": "HRM_jobvacancy.verifyvacancies()"
});
formatter.result({
  "duration": 3687312200,
  "status": "passed"
});
formatter.match({
  "location": "HRM_jobvacancy.closeHRM()"
});
formatter.result({
  "duration": 3432318900,
  "status": "passed"
});
});