$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("HRM_MultipleEmployees.feature");
formatter.feature({
  "line": 2,
  "name": "adding multiple employees",
  "description": "",
  "id": "adding-multiple-employees",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@hrmaddmultipleemployees"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "To add multiple employees for company",
  "description": "",
  "id": "adding-multiple-employees;to-add-multiple-employees-for-company",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User has to login to HRM page using credentials provided and click on PIM and add employee button",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "using table below fill the details from \"\u003cFirstName\u003e\" and \"\u003cLastName\u003e\" and \"\u003cEmployeeID\u003e\" and \"\u003cusername\u003e\" and \"\u003cpassword\u003e\" and save it",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "verify that employee profile has been created by using \"\u003cEmployeeID\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the employee page and browser",
  "keyword": "And "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "adding-multiple-employees;to-add-multiple-employees-for-company;",
  "rows": [
    {
      "cells": [
        "FirstName",
        "LastName",
        "EmployeeID",
        "username",
        "password"
      ],
      "line": 12,
      "id": "adding-multiple-employees;to-add-multiple-employees-for-company;;1"
    },
    {
      "cells": [
        "Nandinu",
        "JN",
        "12345012",
        "nandinjn",
        "nandinijnwe"
      ],
      "line": 13,
      "id": "adding-multiple-employees;to-add-multiple-employees-for-company;;2"
    },
    {
      "cells": [
        "Nandin25",
        "nandu",
        "4567012",
        "nanduin25",
        "restinpeace"
      ],
      "line": 14,
      "id": "adding-multiple-employees;to-add-multiple-employees-for-company;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 13,
  "name": "To add multiple employees for company",
  "description": "",
  "id": "adding-multiple-employees;to-add-multiple-employees-for-company;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@hrmaddmultipleemployees"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User has to login to HRM page using credentials provided and click on PIM and add employee button",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "using table below fill the details from \"Nandinu\" and \"JN\" and \"12345012\" and \"nandinjn\" and \"nandinijnwe\" and save it",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "verify that employee profile has been created by using \"12345012\"",
  "matchedColumns": [
    2
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the employee page and browser",
  "keyword": "And "
});
formatter.match({
  "location": "HRM_MultipleEmployees.logintohrm()"
});
formatter.result({
  "duration": 9744817600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Nandinu",
      "offset": 41
    },
    {
      "val": "JN",
      "offset": 55
    },
    {
      "val": "12345012",
      "offset": 64
    },
    {
      "val": "nandinjn",
      "offset": 79
    },
    {
      "val": "nandinijnwe",
      "offset": 94
    }
  ],
  "location": "HRM_MultipleEmployees.employedetails(String,String,String,String,String)"
});
formatter.result({
  "duration": 2065227400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "12345012",
      "offset": 56
    }
  ],
  "location": "HRM_MultipleEmployees.employeelist(String)"
});
formatter.result({
  "duration": 1158483600,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleEmployees.closeemployeebrowser()"
});
formatter.result({
  "duration": 1429386800,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "To add multiple employees for company",
  "description": "",
  "id": "adding-multiple-employees;to-add-multiple-employees-for-company;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@hrmaddmultipleemployees"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User has to login to HRM page using credentials provided and click on PIM and add employee button",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "using table below fill the details from \"Nandin25\" and \"nandu\" and \"4567012\" and \"nanduin25\" and \"restinpeace\" and save it",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "verify that employee profile has been created by using \"4567012\"",
  "matchedColumns": [
    2
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the employee page and browser",
  "keyword": "And "
});
formatter.match({
  "location": "HRM_MultipleEmployees.logintohrm()"
});
formatter.result({
  "duration": 8319706200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Nandin25",
      "offset": 41
    },
    {
      "val": "nandu",
      "offset": 56
    },
    {
      "val": "4567012",
      "offset": 68
    },
    {
      "val": "nanduin25",
      "offset": 82
    },
    {
      "val": "restinpeace",
      "offset": 98
    }
  ],
  "location": "HRM_MultipleEmployees.employedetails(String,String,String,String,String)"
});
formatter.result({
  "duration": 1693812000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "4567012",
      "offset": 56
    }
  ],
  "location": "HRM_MultipleEmployees.employeelist(String)"
});
formatter.result({
  "duration": 1063987700,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleEmployees.closeemployeebrowser()"
});
formatter.result({
  "duration": 1795371700,
  "status": "passed"
});
});