$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("HRM_MultipleVacancies.feature");
formatter.feature({
  "line": 2,
  "name": "creatinf multiple vacancies",
  "description": "",
  "id": "creatinf-multiple-vacancies",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@hrmmultiplevacancies"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Create the multiple vacancies on company web page",
  "description": "",
  "id": "creatinf-multiple-vacancies;create-the-multiple-vacancies-on-company-web-page",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "Username and password has been provided to login to HRM page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user logged in , click on Recruitment page",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Click on the Vacancies menu item and click on Add button to add vacancies",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Fill the necessary details about the vacancies \"\u003cJobTitle\u003e\" and \"\u003cVacancyName\u003e\" and \"\u003cHiringManager\u003e\" and \"\u003cPositions\u003e\" and save it",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "verify that all the vacancies has been created successfully using \"\u003cJobTitle\u003e\" and \"\u003cVacancyName\u003e\" and \"\u003cHiringManager\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Close the HRM web page",
  "keyword": "And "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "creatinf-multiple-vacancies;create-the-multiple-vacancies-on-company-web-page;",
  "rows": [
    {
      "cells": [
        "JobTitle",
        "VacancyName",
        "HiringManager",
        "Positions"
      ],
      "line": 14,
      "id": "creatinf-multiple-vacancies;create-the-multiple-vacancies-on-company-web-page;;1"
    },
    {
      "cells": [
        "DevOps Engineer",
        "DevOps test Engineer",
        "Priya J",
        "5"
      ],
      "line": 15,
      "id": "creatinf-multiple-vacancies;create-the-multiple-vacancies-on-company-web-page;;2"
    },
    {
      "cells": [
        "Android Developer",
        "Android test/developer",
        "Priya J",
        "5"
      ],
      "line": 16,
      "id": "creatinf-multiple-vacancies;create-the-multiple-vacancies-on-company-web-page;;3"
    },
    {
      "cells": [
        "Java Developer",
        "Java Web developer",
        "Priya J",
        "10"
      ],
      "line": 17,
      "id": "creatinf-multiple-vacancies;create-the-multiple-vacancies-on-company-web-page;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 15,
  "name": "Create the multiple vacancies on company web page",
  "description": "",
  "id": "creatinf-multiple-vacancies;create-the-multiple-vacancies-on-company-web-page;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@hrmmultiplevacancies"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "Username and password has been provided to login to HRM page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user logged in , click on Recruitment page",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Click on the Vacancies menu item and click on Add button to add vacancies",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Fill the necessary details about the vacancies \"DevOps Engineer\" and \"DevOps test Engineer\" and \"Priya J\" and \"5\" and save it",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "verify that all the vacancies has been created successfully using \"DevOps Engineer\" and \"DevOps test Engineer\" and \"Priya J\"",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Close the HRM web page",
  "keyword": "And "
});
formatter.match({
  "location": "HRM_MultipleVacancies.logintoHRM()"
});
formatter.result({
  "duration": 9156449700,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleVacancies.recruitmentpage()"
});
formatter.result({
  "duration": 848099000,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleVacancies.vacanciespage()"
});
formatter.result({
  "duration": 887219700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "DevOps Engineer",
      "offset": 48
    },
    {
      "val": "DevOps test Engineer",
      "offset": 70
    },
    {
      "val": "Priya J",
      "offset": 97
    },
    {
      "val": "5",
      "offset": 111
    }
  ],
  "location": "HRM_MultipleVacancies.multiplevacanciescreate(String,String,String,String)"
});
formatter.result({
  "duration": 1207468600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "DevOps Engineer",
      "offset": 67
    },
    {
      "val": "DevOps test Engineer",
      "offset": 89
    },
    {
      "val": "Priya J",
      "offset": 116
    }
  ],
  "location": "HRM_MultipleVacancies.verifyvacancies(String,String,String)"
});
formatter.result({
  "duration": 2619703200,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleVacancies.closeRpage()"
});
formatter.result({
  "duration": 1407616800,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "Create the multiple vacancies on company web page",
  "description": "",
  "id": "creatinf-multiple-vacancies;create-the-multiple-vacancies-on-company-web-page;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@hrmmultiplevacancies"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "Username and password has been provided to login to HRM page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user logged in , click on Recruitment page",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Click on the Vacancies menu item and click on Add button to add vacancies",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Fill the necessary details about the vacancies \"Android Developer\" and \"Android test/developer\" and \"Priya J\" and \"5\" and save it",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "verify that all the vacancies has been created successfully using \"Android Developer\" and \"Android test/developer\" and \"Priya J\"",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Close the HRM web page",
  "keyword": "And "
});
formatter.match({
  "location": "HRM_MultipleVacancies.logintoHRM()"
});
formatter.result({
  "duration": 8024594600,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleVacancies.recruitmentpage()"
});
formatter.result({
  "duration": 743527500,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleVacancies.vacanciespage()"
});
formatter.result({
  "duration": 1235144100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Android Developer",
      "offset": 48
    },
    {
      "val": "Android test/developer",
      "offset": 72
    },
    {
      "val": "Priya J",
      "offset": 101
    },
    {
      "val": "5",
      "offset": 115
    }
  ],
  "location": "HRM_MultipleVacancies.multiplevacanciescreate(String,String,String,String)"
});
formatter.result({
  "duration": 1376687400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Android Developer",
      "offset": 67
    },
    {
      "val": "Android test/developer",
      "offset": 91
    },
    {
      "val": "Priya J",
      "offset": 120
    }
  ],
  "location": "HRM_MultipleVacancies.verifyvacancies(String,String,String)"
});
formatter.result({
  "duration": 2631805300,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleVacancies.closeRpage()"
});
formatter.result({
  "duration": 1968136800,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "Create the multiple vacancies on company web page",
  "description": "",
  "id": "creatinf-multiple-vacancies;create-the-multiple-vacancies-on-company-web-page;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@hrmmultiplevacancies"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "Username and password has been provided to login to HRM page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user logged in , click on Recruitment page",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Click on the Vacancies menu item and click on Add button to add vacancies",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Fill the necessary details about the vacancies \"Java Developer\" and \"Java Web developer\" and \"Priya J\" and \"10\" and save it",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "verify that all the vacancies has been created successfully using \"Java Developer\" and \"Java Web developer\" and \"Priya J\"",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Close the HRM web page",
  "keyword": "And "
});
formatter.match({
  "location": "HRM_MultipleVacancies.logintoHRM()"
});
formatter.result({
  "duration": 7525004100,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleVacancies.recruitmentpage()"
});
formatter.result({
  "duration": 687481600,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleVacancies.vacanciespage()"
});
formatter.result({
  "duration": 860936000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Java Developer",
      "offset": 48
    },
    {
      "val": "Java Web developer",
      "offset": 69
    },
    {
      "val": "Priya J",
      "offset": 94
    },
    {
      "val": "10",
      "offset": 108
    }
  ],
  "location": "HRM_MultipleVacancies.multiplevacanciescreate(String,String,String,String)"
});
formatter.result({
  "duration": 1158160200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Java Developer",
      "offset": 67
    },
    {
      "val": "Java Web developer",
      "offset": 88
    },
    {
      "val": "Priya J",
      "offset": 113
    }
  ],
  "location": "HRM_MultipleVacancies.verifyvacancies(String,String,String)"
});
formatter.result({
  "duration": 2648256100,
  "status": "passed"
});
formatter.match({
  "location": "HRM_MultipleVacancies.closeRpage()"
});
formatter.result({
  "duration": 1415813300,
  "status": "passed"
});
});