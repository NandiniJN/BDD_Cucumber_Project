$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("HRM_project2_addrecruitment.feature");
formatter.feature({
  "line": 2,
  "name": "adding candidate for recruitment",
  "description": "",
  "id": "adding-candidate-for-recruitment",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@hrmaddcandidate"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "To add candidates for recruitment in HRM page",
  "description": "",
  "id": "adding-candidate-for-recruitment;to-add-candidates-for-recruitment-in-hrm-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User has to login to HRM page using credentials provided and navigate to Recruitment page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "enter to Recruitment page and click on Add button to add candidate",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Fill the details of the candidate and upload resume on recruitment page",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Once uploaded click on save button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "navigate to recruitment page and confirm the candidate entry",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Close the HRM recruitment page Browser",
  "keyword": "And "
});
formatter.match({
  "location": "HRM_project2_addrecruitment.logintohrmpage()"
});
formatter.result({
  "duration": 17901228300,
  "status": "passed"
});
formatter.match({
  "location": "HRM_project2_addrecruitment.recruitmentpage()"
});
formatter.result({
  "duration": 2097842700,
  "status": "passed"
});
formatter.match({
  "location": "HRM_project2_addrecruitment.candidatedetails()"
});
formatter.result({
  "duration": 3406763000,
  "status": "passed"
});
formatter.match({
  "location": "HRM_project2_addrecruitment.savebutton()"
});
formatter.result({
  "duration": 1025467000,
  "status": "passed"
});
formatter.match({
  "location": "HRM_project2_addrecruitment.confirmentry()"
});
formatter.result({
  "duration": 4340556400,
  "status": "passed"
});
formatter.match({
  "location": "HRM_project2_addrecruitment.closerecruitmentpage()"
});
formatter.result({
  "duration": 6820333400,
  "status": "passed"
});
});