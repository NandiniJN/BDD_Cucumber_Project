$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("postjobs.feature");
formatter.feature({
  "line": 2,
  "name": "posting the job using parameterization",
  "description": "",
  "id": "posting-the-job-using-parameterization",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Postjobs"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "post job using different profiles",
  "description": "",
  "id": "posting-the-job-using-parameterization;post-job-using-different-profiles",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User should post Job on Alchemy page using Post a Job button and sign in if he has account",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "fill the job details from  \"\u003cJobTitle\u003e\" and \"\u003cDescription\u003e\" and save it",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "confirm the job listing in jobs page from  \"\u003cJobTitle\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the Browser after the listing",
  "keyword": "And "
});
formatter.examples({
  "line": 10,
  "name": "",
  "description": "",
  "id": "posting-the-job-using-parameterization;post-job-using-different-profiles;",
  "rows": [
    {
      "cells": [
        "JobTitle",
        "Description"
      ],
      "line": 11,
      "id": "posting-the-job-using-parameterization;post-job-using-different-profiles;;1"
    },
    {
      "cells": [
        "Automation Tester",
        "need to develop the UI screen completely"
      ],
      "line": 12,
      "id": "posting-the-job-using-parameterization;post-job-using-different-profiles;;2"
    },
    {
      "cells": [
        "Test Automation Job",
        "build testplans,testscenarios,testdata"
      ],
      "line": 13,
      "id": "posting-the-job-using-parameterization;post-job-using-different-profiles;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 12,
  "name": "post job using different profiles",
  "description": "",
  "id": "posting-the-job-using-parameterization;post-job-using-different-profiles;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@Postjobs"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User should post Job on Alchemy page using Post a Job button and sign in if he has account",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "fill the job details from  \"Automation Tester\" and \"need to develop the UI screen completely\" and save it",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "confirm the job listing in jobs page from  \"Automation Tester\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the Browser after the listing",
  "keyword": "And "
});
formatter.match({
  "location": "postjobs.jobsitepage()"
});
formatter.result({
  "duration": 12298802400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Automation Tester",
      "offset": 28
    },
    {
      "val": "need to develop the UI screen completely",
      "offset": 52
    }
  ],
  "location": "postjobs.addjob(String,String)"
});
formatter.result({
  "duration": 4186898400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Automation Tester",
      "offset": 44
    }
  ],
  "location": "postjobs.joblist(String)"
});
formatter.result({
  "duration": 2182472900,
  "status": "passed"
});
formatter.match({
  "location": "postjobs.dashboardclosed()"
});
formatter.result({
  "duration": 1763642900,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "post job using different profiles",
  "description": "",
  "id": "posting-the-job-using-parameterization;post-job-using-different-profiles;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@Postjobs"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User should post Job on Alchemy page using Post a Job button and sign in if he has account",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "fill the job details from  \"Test Automation Job\" and \"build testplans,testscenarios,testdata\" and save it",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "confirm the job listing in jobs page from  \"Test Automation Job\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the Browser after the listing",
  "keyword": "And "
});
formatter.match({
  "location": "postjobs.jobsitepage()"
});
formatter.result({
  "duration": 9255487000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Test Automation Job",
      "offset": 28
    },
    {
      "val": "build testplans,testscenarios,testdata",
      "offset": 54
    }
  ],
  "location": "postjobs.addjob(String,String)"
});
formatter.result({
  "duration": 3928574800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Test Automation Job",
      "offset": 44
    }
  ],
  "location": "postjobs.joblist(String)"
});
formatter.result({
  "duration": 2250710400,
  "status": "passed"
});
formatter.match({
  "location": "postjobs.dashboardclosed()"
});
formatter.result({
  "duration": 1933385200,
  "status": "passed"
});
});