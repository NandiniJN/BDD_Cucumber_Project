$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("postJobsUsingFeaturetable.feature");
formatter.feature({
  "line": 2,
  "name": "posting the job using parameterization through feature file",
  "description": "",
  "id": "posting-the-job-using-parameterization-through-feature-file",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Postjobsusingfeaturetable"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "post job using different profiles in feature table",
  "description": "",
  "id": "posting-the-job-using-parameterization-through-feature-file;post-job-using-different-profiles-in-feature-table",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User should post Job on Alchemy page using Post a Job button and sign in if he has account for Alchemy",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "fill the job details \"Automation Tester\" and \"need to develop the UI screen completely\" and save it",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "confirm the job listing in jobs page for \"Automation Tester\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the Browser after posting job",
  "keyword": "And "
});
formatter.match({
  "location": "postJobsUsingFeaturetable.loginjobsite()"
});
formatter.result({
  "duration": 12790089300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Automation Tester",
      "offset": 22
    },
    {
      "val": "need to develop the UI screen completely",
      "offset": 46
    }
  ],
  "location": "postJobsUsingFeaturetable.addjob(String,String)"
});
formatter.result({
  "duration": 4008148600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Automation Tester",
      "offset": 42
    }
  ],
  "location": "postJobsUsingFeaturetable.joblist(String)"
});
formatter.result({
  "duration": 2248257200,
  "status": "passed"
});
formatter.match({
  "location": "postJobsUsingFeaturetable.postjobclosed()"
});
formatter.result({
  "duration": 1303551900,
  "status": "passed"
});
});