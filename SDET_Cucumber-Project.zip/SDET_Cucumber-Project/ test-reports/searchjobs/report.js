$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("searchjobs.feature");
formatter.feature({
  "line": 2,
  "name": "Searching for jobs",
  "description": "",
  "id": "searching-for-jobs",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@searchjobs"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "search for jobs and apply",
  "description": "",
  "id": "searching-for-jobs;search-for-jobs-and-apply",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user need to open job site and navigate to job page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "search for jobs in keyword field and change the job type to \"Full Time\" jobs using filter",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "find the job listing and check for job details",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "find and print the title of the job",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "click on \"Apply for job\" button",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Close the job page browser",
  "keyword": "And "
});
formatter.match({
  "location": "searchjobs.openjobssite()"
});
formatter.result({
  "duration": 9133721200,
  "status": "passed"
});
formatter.match({
  "location": "searchjobs.fulltime()"
});
formatter.result({
  "duration": 1784097000,
  "status": "passed"
});
formatter.match({
  "location": "searchjobs.listofjobs()"
});
formatter.result({
  "duration": 1470472000,
  "status": "passed"
});
formatter.match({
  "location": "searchjobs.titleofjob()"
});
formatter.result({
  "duration": 51483800,
  "status": "passed"
});
formatter.match({
  "location": "searchjobs.applyingforjob()"
});
formatter.result({
  "duration": 904264900,
  "status": "passed"
});
formatter.match({
  "location": "searchjobs.jobpageclosed()"
});
formatter.result({
  "duration": 1260074400,
  "status": "passed"
});
});