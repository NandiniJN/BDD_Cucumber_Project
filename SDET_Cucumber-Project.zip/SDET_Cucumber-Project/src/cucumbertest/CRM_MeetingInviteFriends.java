package cucumbertest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(

    features = "src/featureFiles",

    glue = {"stepDefinition"},

    tags = {"@CRMMeetingfriends"},

    strict = true,
    plugin = {"pretty" , "html: test-reports/CRMmeeting" , "json: test-reports/CRMmeeting/json-report.json"},
    monochrome = true


)



public class CRM_MeetingInviteFriends {

}
