package cucumbertest;


import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(

    features = "src/featureFiles",

    glue = {"stepDefinition"},

    tags = {"@createusername"},

    strict = true,
    plugin = {"pretty" , "html: test-reports/CreateUserName" , "json: test-reports/CreateUserName/json-report.json"},
    monochrome = true


)

public class CreateUserName {

}
