package cucumbertest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(

    features = "src/featureFiles",

    glue = {"stepDefinition"},

    tags = {"@hrmaddmultipleemployees"},

    strict = true,
    plugin = {"pretty" , "html: test-reports/HRMMultipleEmployee" , "json: test-reports/HRMMultipleEmployee/json-report.json"},
    monochrome = true


)

public class HRM_MultipleEmployees {

}
