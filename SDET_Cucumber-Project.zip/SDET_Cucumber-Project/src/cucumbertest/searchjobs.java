package cucumbertest;


import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(

    features = "src/featureFiles",

    glue = {"stepDefinition"},

    tags = {"@searchjobs"},

    strict = true,
    plugin = {"pretty" , "html: test-reports/searchjobs" , "json: test-reports/searchjobs/json-report.json"},
    monochrome = true


)


public class searchjobs {

}
