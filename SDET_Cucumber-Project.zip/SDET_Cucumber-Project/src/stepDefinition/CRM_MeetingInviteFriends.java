package stepDefinition;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CRM_MeetingInviteFriends {
	
	WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Login to CRM with credentials$")
    public void logintoCRMpage()
    {
    	
    	driver = new FirefoxDriver();	
		wait = new WebDriverWait(driver, 10);
		
		driver.get("http://alchemy.hguy.co/crm");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.findElement(By.id("user_name")).sendKeys("admin");
		driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
    
    
	@And("^Navigate to Activities then Meetings and then Schedule a Meeting$")
	public void ScheduleMeeting() throws Throwable
	{
		driver.findElement(By.xpath("//a[text()='Activities']")).click();

		JavascriptExecutor js=(JavascriptExecutor)driver;

		js.executeScript("arguments[0].click()",		

		driver.findElement(By.xpath("//a[text()='Meetings']")));

		Thread.sleep(3000);

		driver.findElement(By.xpath("//div[text()='Schedule Meeting']")).click();

		Thread.sleep(3000);
	}

	@And("^Enter the \"([^\"]*)\" and Search for members \"([^\"]*)\" and add them to the meeting$")
	public void bookmeeting(String Subject, String Name) throws Throwable 
	{
		driver.findElement(By.id("name")).sendKeys(Subject);
		
		Actions days = new Actions(driver);
	      days.sendKeys(Keys.chord(Keys.DOWN)).perform();
		
		driver.findElement(By.id("search_first_name")).sendKeys(Name);
		Thread.sleep(2000);
		driver.findElement(By.id("invitees_search")).click();
		
		Actions save = new Actions(driver);
	      save.sendKeys(Keys.chord(Keys.DOWN)).perform();
	      Thread.sleep(2000);
				
		driver.findElement(By.xpath("//*[@id=\"invitees_add_1\"]")).click();
		Thread.sleep(2000);

		
	}

	@And("^Click Save Meeting to finish$")
	public void click_Save() throws Throwable {
		driver.findElement(By.id("SAVE_HEADER")).click();

		Thread.sleep(1000);
	}

	@When("^Navigate to View Meetings page and confirm creation of the meeting for \"([^\"]*)\"$")
	public void ConfirmMeeting(String Meeting) throws Throwable {
		driver.findElement(By.xpath("//div[text()='View Meetings']")).click();

		Thread.sleep(2000);

		String confirm = driver.findElement(By.xpath("//table[@class='list view table-responsive']/tbody//td[@field='name']/b/a")).getText();

		if(confirm.contains(Meeting)) {

			System.out.println("Creation of meeting is successful");

		}

		else {

			System.out.println("Creation of meeting is not successful");

		}
	}

	@Then("^close the CRM browser$")
	public void CloseCRMBrowser() 
 {
	    driver.close();
	}
}
