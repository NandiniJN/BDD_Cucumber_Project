package stepDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CRM_countingdashlets {
	
	WebDriver driver;

    WebDriverWait wait;

    @Given("^User has to login to CRM page using credentials$")
    public void logintoCRMpage()
    {
    	driver = new FirefoxDriver();

        wait = new WebDriverWait(driver, 10);
        
        driver.get("https://alchemy.hguy.co/crm/index.php?action=Login&module=Users");
        driver.manage().window().maximize();
        
        driver.findElement(By.id("user_name")).click();
    	driver.findElement(By.id("user_name")).sendKeys("admin");
    	
    	driver.findElement(By.id("username_password")).click();
    	driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
    	
    	driver.findElement(By.id("bigbutton")).click();
    	
    }
    
    

    @Given("^Count the number of dashlets on CRM Page$")
    public void count_the_number_of_Dashlets_on_Hompepage() throws Throwable {
   	
   	List<WebElement> count = driver.findElements(By.className("dashlet-title"));
     	 System.out.println("Count of Dashlets on HomePage : " +count.size()); 
     	 
     	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
   }

    @Then("^print the number of dashlets into console$")
    public void print_the_number_of_dashlets_into_console() throws Throwable {
    	 	 
   	List<WebElement> listElement = driver.findElements(By.className("dashlet-title"));
   	for(int i =0;i<listElement.size();i++) {
   	 String elementText = listElement.get(i).getText(); 
   	 System.out.println("Printing the title of Dashlets: " +elementText); 
   	 
   	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
   	}
   	
    }
    
   @And("^Close the CRM Browser$")
   public void closeCRMpage()
   {
	   driver.close();
   }
}

