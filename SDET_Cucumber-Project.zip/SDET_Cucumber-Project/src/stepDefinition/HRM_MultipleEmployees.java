package stepDefinition;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.support.ui.WebDriverWait;

// import com.sun.org.apache.bcel.internal.generic.Select;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HRM_MultipleEmployees {
	
	WebDriver driver;

    WebDriverWait wait;

    @Given("^User has to login to HRM page using credentials provided and click on PIM and add employee button$")
    public void logintohrm()
    {
    	driver = new FirefoxDriver();

        wait = new WebDriverWait(driver, 10);
        
        driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
        driver.manage().window().maximize();
        
     
        
        driver.findElement(By.id("txtUsername")).sendKeys("orange");
        
        driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
        
   
        driver.findElement(By.id("btnLogin")).click();
        
        System.out.println("logged into HRM page");
        
        driver.findElement(By.xpath("//*[@id=\"menu_pim_viewPimModule\"]")).click();
       
        
        driver.findElement(By.xpath("//*[@id=\"btnAdd\"]")).click();
        
    }
    
       
        
    @When("^using table below fill the details from FirstName and LastName and EmployeeID and username and password and save it$")
    public void employeedetails()
    {
    	//adding employee details
    	
    	driver.findElement(By.id("firstName")).sendKeys("Nandini");
    	driver.findElement(By.id("lastName")).sendKeys("JN");
    	
    
   // 	driver.findElement(By.xpath("//*[@id=\"firstName\"]")).sendKeys("sakshi");
   // 	driver.findElement(By.xpath("//*[@id=\"lastName\"]")).sendKeys("aradhya");
    	
    	driver.findElement(By.xpath("//*[@id=\"employeeId\"]")).clear();
    	driver.findElement(By.xpath("//*[@id=\"employeeId\"]")).sendKeys("232425");
    	
    	//check box
    	driver.findElement(By.id("chkLogin")).click();
    	driver.findElement(By.id("chkLogin")).isSelected();
    	System.out.println("check box is selected");
    	
    	//user profile
    	driver.findElement(By.id("user_name")).sendKeys("sakshi");
    	driver.findElement(By.id("user_password")).sendKeys("sakshi1234");
    	driver.findElement(By.id("re_password")).sendKeys("sakshi1234");
    	
    	//save it
    	driver.findElement(By.id("btnSave")).click();
    	System.out.println("employee added");
    }
    
    
    @When("^using table below fill the details from \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and save it$")
    public void employedetails(String FirstName , String lastName , String EmployeeID , String username , String password)
    {
    	//adding employee details
    
    	driver.findElement(By.id("firstName")).sendKeys(FirstName);
    	driver.findElement(By.id("lastName")).sendKeys(lastName);
    	
    	driver.findElement(By.xpath("//*[@id=\"employeeId\"]")).clear();
    	driver.findElement(By.xpath("//*[@id=\"employeeId\"]")).sendKeys(EmployeeID);
    	
    	//check box
    	driver.findElement(By.id("chkLogin")).click();
    	driver.findElement(By.id("chkLogin")).isSelected();
    	System.out.println("check box is selected");
    	
    	//user profile
    	driver.findElement(By.id("user_name")).sendKeys(username);
    	driver.findElement(By.id("user_password")).sendKeys(password);
    	driver.findElement(By.id("re_password")).sendKeys(password);
    	
    	//save it
    	driver.findElement(By.id("btnSave")).click();
    	System.out.println("employee added");
    }
    
    @Then("^verify that employee profile has been created by using \"([^\"]*)\"$")
    public void employeelist(String EmployeeID)
    {
    	 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    	driver.findElement(By.xpath("//*[@id=\"menu_pim_viewEmployeeList\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"empsearch_id\"]")).sendKeys(EmployeeID);
    	driver.findElement(By.id("searchBtn")).click();
    	
    	String id = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[2]/a")).getText();
    	
    	System.out.println("the employee ID is : " + id);
    	
    	String Firstname = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[3]/a")).getText();
    	System.out.println("the employee first name is :" + Firstname);
    	
    	String lastname = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[4]/a")).getText();
    	System.out.println("the employee last name is : " + lastname);
    	
    	System.out.println("employee profile is successfully created");
    		
    	
    }
    
    @And("^Close the employee page and browser$")
    public void closeemployeebrowser()
    {
    	driver.close();
    }
    
}
