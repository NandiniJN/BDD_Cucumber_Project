package stepDefinition;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.support.ui.WebDriverWait;

// import com.sun.org.apache.bcel.internal.generic.Select;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HRM_MultipleVacancies {
	
	WebDriver driver;

    WebDriverWait wait;

    @Given("^Username and password has been provided to login to HRM page$")
    public void logintoHRM()
    {
    	driver = new FirefoxDriver();

        wait = new WebDriverWait(driver, 10);
        
        driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
        driver.manage().window().maximize();
        
     
        
        driver.findElement(By.id("txtUsername")).sendKeys("orange");
        
        driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
        
   
        driver.findElement(By.id("btnLogin")).click();
        
        System.out.println("logged into HRM page");

        
    }
    
    @When("^user logged in , click on Recruitment page$")
    public void recruitmentpage()
    {
    	driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewRecruitmentModule\"]")).click();
    	
    }
    
    @Then("^Click on the Vacancies menu item and click on Add button to add vacancies$")
    public void vacanciespage()
    {
    	driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewJobVacancy\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"btnAdd\"]")).click();
    }
    
    @And("^Fill the necessary details about the vacancies JobTitle and VacancyName and HiringManager and Positions and save it$")
    public void multiplevacancies()
    {
    	driver.findElement(By.xpath("//*[@id=\"addJobVacancy_jobTitle\"]")).click();
  	  
    	WebElement element = driver.findElement(By.name("addJobVacancy[jobTitle]")); 
    	Select job = new Select(element); 
    	job.selectByVisibleText("DevOps Engineer");
    	
   
    	driver.findElement(By.id("addJobVacancy_name")).sendKeys("Automation Test/devops specialist");
    	
    
    	driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys("Priya J");
    	
    	driver.findElement(By.xpath("//*[@id=\"addJobVacancy_noOfPositions\"]")).sendKeys("4");
    	
    	driver.findElement(By.id("btnSave")).click();
    	
    	System.out.println("vacancy details has been filled");
    	
    }
    
    @And("^Fill the necessary details about the vacancies \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and save it$")
    public void multiplevacanciescreate(String JobTitle , String VacancyName , String HiringManager , String Positions)
    {
    	driver.findElement(By.xpath("//*[@id=\"addJobVacancy_jobTitle\"]")).click();
  	  
    	WebElement element = driver.findElement(By.name("addJobVacancy[jobTitle]")); 
    	Select job = new Select(element); 
    	job.selectByVisibleText(JobTitle);
    	
   
    	driver.findElement(By.id("addJobVacancy_name")).sendKeys(VacancyName);
    	
    
    	driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys(HiringManager);
    	
    	driver.findElement(By.xpath("//*[@id=\"addJobVacancy_noOfPositions\"]")).sendKeys(Positions);
    	
    	driver.findElement(By.id("btnSave")).click();
    	
    	System.out.println("vacancy details has been filled");
    	
    }
    
    @And("^verify that all the vacancies has been created successfully using JobTitle and VacancyName and HiringManager$")
    public void verifyVacancies()
    {
    	driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewJobVacancy\"]")).click();
    	
    	//select job title
    	driver.findElement(By.id("vacancySearch_jobTitle")).click();
    	
    	WebElement title = driver.findElement(By.name("vacancySearch[jobTitle]")); 
    	Select job = new Select(title); 
    	job.selectByVisibleText("DevOps Engineer");
    	
    	//select vacancy 
    	driver.findElement(By.id("vacancySearch_jobVacancy")).click();
    	
    	WebElement vacancy = driver.findElement(By.name("vacancySearch[jobVacancy]")); 
    	Select test = new Select(vacancy); 
    	test.selectByVisibleText("Testing");
    	
    	//select hiring manager
    	driver.findElement(By.id("vacancySearch_hiringManager")).click();
    	
    	WebElement manager = driver.findElement(By.name("vacancySearch[hiringManager]")); 
    	Select hire = new Select(manager); 
    	hire.selectByVisibleText("Priya J");
    	
    	driver.findElement(By.id("btnSrch")).click();
    	
    	//verify the vacancy and job title
    	String vacancytest = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[2]/a")).getText();
    	System.out.println("vacancy is : " + vacancytest);
    	
    	String jobtitle = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[3]")).getText();
    	System.out.println("The Job Title is :" + jobtitle);
    	
    	String hiremanager = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[4]")).getText();
    	System.out.println("Hiring manager Name is : " + hiremanager);
    	
    	
    	//asset the values
    	Assert.assertEquals(vacancytest, "Testing");
    	
    	Assert.assertEquals(jobtitle, "DevOps Engineer");
    	
    	Assert.assertEquals(hiremanager, "Priya J");
    }
    
    @And("^verify that all the vacancies has been created successfully using \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verifyvacancies(String JobTitle , String VacancyName , String HiringManager)
    {
    	driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewJobVacancy\"]")).click();
    	
    	//select job title
    	driver.findElement(By.id("vacancySearch_jobTitle")).click();
    	
    	WebElement title = driver.findElement(By.name("vacancySearch[jobTitle]")); 
    	Select job = new Select(title); 
    	job.selectByVisibleText(JobTitle);
    	
    	//select vacancy 
    	driver.findElement(By.id("vacancySearch_jobVacancy")).click();
    	
    	WebElement vacancy = driver.findElement(By.name("vacancySearch[jobVacancy]")); 
    	Select test = new Select(vacancy); 
    	test.selectByVisibleText(VacancyName);
    	
    	//select hiring manager
    	driver.findElement(By.id("vacancySearch_hiringManager")).click();
    	
    	WebElement manager = driver.findElement(By.name("vacancySearch[hiringManager]")); 
    	Select hire = new Select(manager); 
    	hire.selectByVisibleText(HiringManager);
    	
    	driver.findElement(By.id("btnSrch")).click();
    	
    	//verify the vacancy and job title
    	String vacancytest = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[2]/a")).getText();
    	System.out.println("vacancy is : " + vacancytest);
    	
    	String jobtitle = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[3]")).getText();
    	System.out.println("The Job Title is :" + jobtitle);
    	
    	String hiremanager = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[4]")).getText();
    	System.out.println("Hiring manager Name is : " + hiremanager);
    	
    	
    	//asset the values
    	Assert.assertEquals(vacancytest, VacancyName);
    	
    	Assert.assertEquals(jobtitle, JobTitle);
    	
    	Assert.assertEquals(hiremanager, HiringManager);
    }
    
    
    @And("^Close the HRM web page$")

    public void closeRpage() {

        driver.close();

    }
    
}
