package stepDefinition;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.support.ui.WebDriverWait;

// import com.sun.org.apache.bcel.internal.generic.Select;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class HRM_jobvacancy {
	
	WebDriver driver;

    WebDriverWait wait;

    
    @Given("^User has to login to HRM page using credentials and navigate to Recruitment page$")
    public void logintoHRMpage()
    {
    	driver = new FirefoxDriver();

        wait = new WebDriverWait(driver, 10);
        
        driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
        driver.manage().window().maximize();
        
     
        
        driver.findElement(By.id("txtUsername")).sendKeys("orange");
        
        driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
        
   
        driver.findElement(By.id("btnLogin")).click();
        
        System.out.println("logged into HRM page");
        
        driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewRecruitmentModule\"]")).click();
        

    }
    
    @When("^enter to vacancies page and click on Add button$")
    public void vacancypage()
    {
    	driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
    	driver.findElement(By.id("btnAdd")).click();
    }
    
    @When("^In add vacancy form fill out all necessary details and save it$")
    public void vacancyform()
        {
    	  driver.findElement(By.xpath("//*[@id=\"addJobVacancy_jobTitle\"]")).click();
    	  
    	WebElement element = driver.findElement(By.name("addJobVacancy[jobTitle]")); 
    	Select job = new Select(element); 
    	job.selectByVisibleText("DevOps Engineer");
    	
    //	driver.findElement(By.id("addJobVacancy_name")).click();
    	driver.findElement(By.id("addJobVacancy_name")).sendKeys("Automation Test/devops specialist");
    	
    //	driver.findElement(By.id("addJobVacancy_hiringManager")).click();
    	driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys("Priya J");
    	
    	driver.findElement(By.id("btnSave")).click();
    	
    	System.out.println("vacancy details has been filled");
    	
    }
    
    
    @Then("^verify the vacancy was created on the page$")
    public void verifyvacancies()
    {
    
    	driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
    	
    	//select job title
    	driver.findElement(By.id("vacancySearch_jobTitle")).click();
    	
    	WebElement title = driver.findElement(By.name("vacancySearch[jobTitle]")); 
    	Select job = new Select(title); 
    	job.selectByVisibleText("DevOps Engineer");
    	
    	//select vacancy 
    	driver.findElement(By.id("vacancySearch_jobVacancy")).click();
    	
    	WebElement vacancy = driver.findElement(By.name("vacancySearch[jobVacancy]")); 
    	Select test = new Select(vacancy); 
    	test.selectByVisibleText("Automation Test/devops specialist");
    	
    	//select hiring manager
    	driver.findElement(By.id("vacancySearch_hiringManager")).click();
    	
    	WebElement manager = driver.findElement(By.name("vacancySearch[hiringManager]")); 
    	Select hire = new Select(manager); 
    	hire.selectByVisibleText("Priya J");
    	
    	driver.findElement(By.id("btnSrch")).click();
    	
    	//verify the vacancy and job title
    	String vacancytest = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[2]/a")).getText();
    	System.out.println("vacancy is : " + vacancytest);
    	
    	String jobtitle = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[3]")).getText();
    	System.out.println("The Job Title is :" + jobtitle);
    	
    	String hiremanager = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr/td[4]")).getText();
    	System.out.println("Hiring manager Name is : " + hiremanager);
    	
    	
    	//asset the values
    	Assert.assertEquals(vacancytest, "Automation Test/devops specialist");
    	
    	Assert.assertEquals(jobtitle, "DevOps Engineer");
    	
    	Assert.assertEquals(hiremanager, "Priya J");
    
    }
    
    @And("^Close the HRM Browser$")

    public void closeHRM() {

        driver.close();

    }
    
    
}
