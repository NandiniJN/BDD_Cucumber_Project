package stepDefinition;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

// import com.sun.org.apache.bcel.internal.generic.Select;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class HRM_project2_addrecruitment {
	
	WebDriver driver;

    WebDriverWait wait;

    @Given("^User has to login to HRM page using credentials provided and navigate to Recruitment page$")
    public void logintohrmpage()
    {
    	driver = new FirefoxDriver();

        wait = new WebDriverWait(driver, 10);
        
        driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
        driver.manage().window().maximize();
        
     
        
        driver.findElement(By.id("txtUsername")).sendKeys("orange");
        
        driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
        
   
        driver.findElement(By.id("btnLogin")).click();
        
        System.out.println("logged into HRM page");
        
        driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewRecruitmentModule\"]")).click();
        
    }

    @When("^enter to Recruitment page and click on Add button to add candidate$")
    public void recruitmentpage()
    {
    	//click on candidate menu item
    	driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewCandidates\"]")).click();
    	
    	driver.findElement(By.id("btnAdd")).click();
    	
    }
    
    @Then("^Fill the details of the candidate and upload resume on recruitment page$")
    public void candidatedetails() throws InterruptedException
    {
    	driver.findElement(By.id("addCandidate_firstName")).sendKeys("Nandini");
    	driver.findElement(By.id("addCandidate_lastName")).sendKeys("J N");
    	driver.findElement(By.id("addCandidate_email")).sendKeys("nandjn25@in.ibm.com");
    	
    	driver.findElement(By.id("addCandidate_vacancy")).click();
    	
    	WebElement vacancy = driver.findElement(By.name("addCandidate[vacancy]")); 
    	Select test = new Select(vacancy); 
    	test.selectByVisibleText("Automation Test/devops specialist");
    	
    	Thread.sleep(1000);
    	
    	driver.findElement(By.id("addCandidate_resume")).sendKeys("C:\\Users\\NandiniJNJN\\Desktop\\NANDINI J N_Resume.docx");
    	Thread.sleep(1000);
    	
    	Actions days = new Actions(driver);
	      days.sendKeys(Keys.chord(Keys.DOWN)).perform();
	      
	     
    
    }
    
    @And("^Once uploaded click on save button$")
    public void savebutton()
    {
    	 driver.findElement(By.id("btnSave")).click();
     	
    }
    
    @And("^navigate to recruitment page and confirm the candidate entry$")
    public void confirmentry()
    {
    	driver.findElement(By.id("menu_recruitment_viewCandidates")).click();
    	
    	//select job title
    	driver.findElement(By.id("candidateSearch_jobTitle")).click();
    	
    	WebElement title = driver.findElement(By.name("candidateSearch[jobTitle]")); 
    	Select job = new Select(title); 
    	job.selectByVisibleText("DevOps Engineer");
    	
    	//select candidate name
    	driver.findElement(By.id("candidateSearch_candidateName")).sendKeys("Nandini J N");
    	
    	//select vacancy
    	driver.findElement(By.id("candidateSearch_jobVacancy")).click();
    	WebElement candvacancy = driver.findElement(By.name("candidateSearch[jobVacancy]")); 
    	Select candvacn = new Select(candvacancy); 
    	candvacn.selectByVisibleText("Automation Test/devops specialist");
    	
    	driver.findElement(By.id("btnSrch")).click();
    	
    	
    	//verify the candidate entry
    	String vacancyname = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr[1]/td[2]")).getText();
    	System.out.println("vacancy name is : " + vacancyname);
    	
    	//candidate name
    	String candidatename = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr[1]/td[3]/a")).getText();
    	System.out.println("candidate name is : " + candidatename);
    	
    	//resume status
    	String resumestatus = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr[1]/td[7]")).getText();
    	System.out.println("resume status : " + resumestatus);
    	
    	//application status
    	String appstatus = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/form/div[4]/table/tbody/tr[1]/td[6]")).getText();
    	System.out.println("application status : " + appstatus);
    	
    
    	
    	//asset the values
    	Assert.assertEquals(vacancyname, "Automation Test/devops specialist");
    	
    	Assert.assertEquals(candidatename, "Nandini J N");
    	
    	Assert.assertEquals(resumestatus, "Download");
    	
    	Assert.assertEquals(appstatus, "Application Initiated");
    
    	
    }
    
    @And("^Close the HRM recruitment page Browser$")

    public void closerecruitmentpage() {

        driver.close();

    }
    
}
