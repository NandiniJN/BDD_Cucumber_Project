package stepDefinition;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class createNewUser {
	
	WebDriver driver;

    WebDriverWait wait;
    
    @Given("^User is on admin page and login$")
    
    public void adminpage() {
    	
    	driver = new FirefoxDriver();

        wait = new WebDriverWait(driver, 10);
        
        driver.get("https://alchemy.hguy.co/jobs/wp-admin");
        driver.manage().window().maximize();
        
        
    }
    
    @When("^User enters the user name and password$")
    
    public void entervalidcredentials()
    {
    	
    	driver.findElement(By.id("user_login")).sendKeys("root");
    	driver.findElement(By.id("user_pass")).sendKeys("pa$$w0rd");
    	driver.findElement(By.id("wp-submit")).click();
    	
    }

    @Then("^User need to locate the menu item and click on Users button$")
    
    public void menuitem()
    {
    	driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/ul/li[11]/a/div[3]")).click();
    	
    	
    	
    }
    
    @And("^click \"Add New\" button$")
    
    public void addnewuser()
    {
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div[4]/a")).click();
    }
    
    
    @And("^fill necessary details and click on \"Add New User\" button$")
    
    public void filldetails()
    {
    	driver.findElement(By.id("user_login")).sendKeys("nandinijn");
    	driver.findElement(By.id("email")).sendKeys("nandini25jn@gmail.com");
    	driver.findElement(By.id("first_name")).sendKeys("nandinijn");
    	driver.findElement(By.id("createusersub")).click();
    	
    }
    
    @And("^verify the user details after adding$")
    
    public void verifydetails()
    {
    	 driver.findElement(By.id("user-search-input")).click();
    	 driver.findElement(By.id("user-search-input")).sendKeys("nandinijn");
    	 driver.findElement(By.id("search-submit")).click();
    	 
    	 wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div[4]/form/table/tbody/tr/td[1]/strong/a")));

   
         String confirmUser = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div[4]/form/table/tbody/tr/td[1]/strong/a")).getText();       
       

         System.out.println("user Profile is : " + confirmUser);

  
         Assert.assertEquals(confirmUser, "nandinijn");

    }
    
    @And("^Close the browser$")
    
    public void browserclose()
    {
    	driver.close();
    }
    
}
