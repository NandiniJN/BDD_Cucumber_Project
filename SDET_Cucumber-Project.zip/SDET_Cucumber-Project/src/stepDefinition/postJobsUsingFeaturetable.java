package stepDefinition;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class postJobsUsingFeaturetable {
	
	WebDriver driver;

    WebDriverWait wait;
    
    @Given("^User should post Job on Alchemy page using Post a Job button and sign in if he has account for Alchemy$")
    public void loginjobsite()
    {
    	driver = new FirefoxDriver();

        wait = new WebDriverWait(driver, 10);

        driver.get("https://alchemy.hguy.co/jobs/");
        driver.manage().window().maximize();
        
        driver.findElement(By.xpath("/html/body/div/header/div/div/div/div/div[3]/div/nav/div/ul/li[3]/a")).click();
        driver.findElement(By.xpath("/html/body/div[1]/div/div/div/main/article/div/form/fieldset[1]/div/a")).click();
    	
    	driver.findElement(By.id("user_login")).sendKeys("root");
    	driver.findElement(By.id("user_pass")).sendKeys("pa$$w0rd");
    	driver.findElement(By.id("wp-submit")).click();
        
    }
    
    @When("^fill the job details \"([^\"]*)\" and \"([^\"]*)\" and save it$")
    
    public void addjob(String JobTitle, String Description) throws Throwable
    {

    	driver.findElement(By.id("job_title")).click();
    	
    	driver.findElement(By.xpath("//*[@id=\"job_title\"]")).sendKeys(JobTitle);
    	
    	driver.findElement(By.xpath("//*[@id=\"job_description_ifr\"]")).click();
    	
    	driver.findElement(By.xpath("//*[@id=\"job_description_ifr\"]")).sendKeys(Description);    
    	
    	Actions days = new Actions(driver);
	      days.sendKeys(Keys.chord(Keys.DOWN)).perform();
		  
	      driver.findElement(By.xpath("/html/body/div[2]/div/div/div/main/article/div/form/p/input[5]")).click();	  
	     	
	    //get job details in job dashboard  
	    	driver.findElement(By.xpath("/html/body/div[2]/div/div/div/main/article/div/div/a")).click();
	    	String jobtitlelist1 = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/main/article/div/div/table/tbody/tr[1]/td[1]")).getText();
	    	System.out.println("job title list : " + jobtitlelist1);
	    	Thread.sleep(1000);
	
	    	  	
    }
    
        
   
    
    @Then("^confirm the job listing in jobs page for \"([^\"]*)\"$")
public void joblist(String JobTitle)
    
    {
    	//search for job in jobs page
	    	
    	driver.findElement(By.xpath("/html/body/div[2]/header/div/div/div/div/div[3]/div/nav/div/ul/li[1]/a")).click();
    	driver.findElement(By.id("search_keywords")).click();
   		driver.findElement(By.id("search_keywords")).sendKeys(JobTitle);
   		
   		
   		driver.findElement(By.xpath("//*[@id=\"job_type_freelance\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_internship\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_part-time\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_temporary\"]")).click();
    	
    	driver.findElement(By.xpath("/html/body/div/div/div/div/main/article/div/div/form/div[1]/div[4]/input")).click();
    	
    	String joblist1 = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/main/article/div/div/ul/li[1]/a/div[1]/h3")).getText();
    	System.out.println("job list 1 : " + joblist1);
    	Assert.assertEquals(joblist1, "Automation Tester");
   	    	
    }
    
    @And("^Close the Browser after posting job$")
    
    public void postjobclosed()
    {
    	driver.close();
    }
    
    
}
