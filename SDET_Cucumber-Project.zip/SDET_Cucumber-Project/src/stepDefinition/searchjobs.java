package stepDefinition;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class searchjobs {
	
	WebDriver driver;

    WebDriverWait wait;
    
    
    @Given("^user need to open job site and navigate to job page$")
    
    public void openjobssite()
    {
    	driver = new FirefoxDriver();

        wait = new WebDriverWait(driver, 10);
        
    	driver.get("https://alchemy.hguy.co/jobs/");
    	driver.manage().window().maximize();
    	driver.findElement(By.xpath("/html/body/div/header/div/div/div/div/div[3]/div/nav/div/ul/li[1]/a")).click();
    	
    }
    
      
    @When("^search for jobs in keyword field and change the job type to \"Full Time\" jobs using filter$")
    public void fulltime() {
    	
    	driver.findElement(By.xpath("//*[@id=\"search_keywords\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"search_keywords\"]")).sendKeys("Application developer");
    	
    	driver.findElement(By.xpath("//*[@id=\"job_type_freelance\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_internship\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_part-time\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_temporary\"]")).click();
    	
    	driver.findElement(By.xpath("/html/body/div/div/div/div/main/article/div/div/form/div[1]/div[4]/input")).click();
    	
    }
    
    @Then ("^find the job listing and check for job details$")
    
    public void listofjobs() throws InterruptedException
    {
    	String joblist =  driver.findElement(By.xpath("/html/body/div/div/div/div/main/article/div/div/ul/li[1]/a/div[1]/h3")).getText();
    	System.out.println("job listing are :" + joblist);
    	Thread.sleep(1000);
    	driver.findElement(By.xpath("/html/body/div/div/div/div/main/article/div/div/ul/li[1]/a/div[1]/h3")).click();
    	
    	
    }
    
    
    @And ("^find and print the title of the job$")
    public void titleofjob()
    {
    	String jobtitle =  driver.findElement(By.xpath("/html/body/div/div/div/div/main/article/div/header/div/h1")).getText();
    	
    	System.out.println("Job Title is : " + jobtitle );
    	
    	String jobdetails = driver.findElement(By.xpath("/html/body/div/div/div/div/main/article/div/div/div/div")).getText();
    	System.out.println("Job Title is : " + jobdetails );
    	
    	
    }
    
    
   	@And ("^click on \"Apply for job\" button$")
   	
   	public void applyingforjob()
   	{
   		// if job expired , click on next job button
   		driver.findElement(By.xpath("/html/body/div/div/div/div/main/nav/div/div/a")).click();
   		String nextjobTitle	= driver.findElement(By.xpath("/html/body/div/div/div/div/main/article/div/header/div/h1")).getText();
   		System.out.println("Job Title to apply : " + nextjobTitle);
   		
   		driver.findElement(By.xpath("/html/body/div/div/div/div/main/article/div/div/div/div[3]/input")).click();
   		
   		Assert.assertEquals(nextjobTitle , "D_testing");
   	}
   	
   	
   	@And("^Close the job page browser$")
    
    public void jobpageclosed()
    {
    	driver.close();
    }
    

}
